# react_webpack_boilerplate

#code to run production npm run build